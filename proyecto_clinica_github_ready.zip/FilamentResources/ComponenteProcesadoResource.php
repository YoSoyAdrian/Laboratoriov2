<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ComponenteProcesadoResource\Pages;
use App\Models\ComponenteProcesado;
use Filament\Forms;
use Filament\Resources\Form;
use Filament\Resources\Table;
use Filament\Resources\Resource;
use Filament\Tables;

class ComponenteProcesadoResource extends Resource
{
    protected static ?string $model = ComponenteProcesado::class;
    protected static ?string $navigationIcon = 'heroicon-o-beaker';
    protected static ?string $navigationGroup = 'Trazabilidad';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Select::make('unidad_transfusional_fk')
                    ->relationship('unidadTransfusional', 'id')
                    ->required(),
                Forms\Components\TextInput::make('tipo_proceso')->required(),
                Forms\Components\TextInput::make('resultado')->required(),
                Forms\Components\DateTimePicker::make('fecha_proceso')->required(),
                Forms\Components\DateTimePicker::make('nueva_fecha_caducidad'),
                Forms\Components\Select::make('user_fk')
                    ->relationship('unidadTransfusional', 'id')
                    ->required(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('tipo_proceso'),
                Tables\Columns\TextColumn::make('resultado'),
                Tables\Columns\TextColumn::make('fecha_proceso')->dateTime(),
                Tables\Columns\TextColumn::make('nueva_fecha_caducidad')->dateTime(),
            ])
            ->filters([]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListComponenteProcesados::route('/'),
            'create' => Pages\CreateComponenteProcesado::route('/create'),
            'edit' => Pages\EditComponenteProcesado::route('/{record}/edit'),
        ];
    }
}
