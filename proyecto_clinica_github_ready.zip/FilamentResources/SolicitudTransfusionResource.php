<?php

namespace App\Filament\Resources;

use App\Filament\Resources\SolicitudTransfusionResource\Pages;
use App\Models\SolicitudTransfusion;
use Filament\Forms;
use Filament\Resources\Form;
use Filament\Resources\Table;
use Filament\Resources\Resource;
use Filament\Tables;

class SolicitudTransfusionResource extends Resource
{
    protected static ?string $model = SolicitudTransfusion::class;
    protected static ?string $navigationIcon = 'heroicon-o-document-text';
    protected static ?string $navigationGroup = 'Trazabilidad';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Select::make('paciente_fk')
                    ->relationship('paciente', 'nombre') // ajusta según campo real
                    ->required(),
                Forms\Components\Select::make('tipo_solicitud')
                    ->options([
                        'rutina' => 'Rutina',
                        'urgente' => 'Urgente',
                        'emergencia' => 'Emergencia',
                    ])
                    ->required(),
                Forms\Components\TextInput::make('numero_muestra')->required(),
                Forms\Components\Select::make('estado')
                    ->options([
                        'pendiente' => 'Pendiente',
                        'completada' => 'Completada',
                        'rechazada' => 'Rechazada',
                    ])
                    ->required(),
                Forms\Components\Textarea::make('observaciones'),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('paciente.nombre'),
                Tables\Columns\TextColumn::make('tipo_solicitud'),
                Tables\Columns\TextColumn::make('numero_muestra'),
                Tables\Columns\TextColumn::make('estado'),
                Tables\Columns\TextColumn::make('created_at')->dateTime(),
            ])
            ->filters([]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListSolicitudTransfusions::route('/'),
            'create' => Pages\CreateSolicitudTransfusion::route('/create'),
            'edit' => Pages\EditSolicitudTransfusion::route('/{record}/edit'),
        ];
    }
}
