<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Empresa extends Model
{
    use HasFactory;

    protected $fillable = ['nombre'];

    public function usuarios()
    {
        return $this->hasMany(User::class);
    }

    public function solicitudesTransfusion()
    {
        return $this->hasMany(SolicitudTransfusion::class);
    }

    public function componentesProcesados()
    {
        return $this->hasMany(ComponenteProcesado::class);
    }
}
