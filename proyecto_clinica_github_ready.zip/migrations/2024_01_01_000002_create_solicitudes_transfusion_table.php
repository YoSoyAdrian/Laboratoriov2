<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('solicitudes_transfusion', function (Blueprint $table) {
            $table->id();
            $table->foreignId('paciente_fk')->constrained('pacientes');
            $table->enum('tipo_solicitud', ['rutina', 'urgente', 'emergencia']);
            $table->timestamp('fecha_solicitud');
            $table->string('numero_muestra')->unique();
            $table->enum('estado', ['pendiente', 'completada', 'rechazada'])->default('pendiente');
            $table->foreignId('user_solicita_fk')->constrained('users');
            $table->text('observaciones')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('solicitudes_transfusion');
    }
};
