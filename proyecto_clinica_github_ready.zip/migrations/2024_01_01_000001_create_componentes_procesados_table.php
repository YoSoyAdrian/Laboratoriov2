<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('componentes_procesados', function (Blueprint $table) {
            $table->id();
            $table->foreignId('unidad_transfusional_fk')->constrained('unidad_transfusionals')->cascadeOnDelete();
            $table->string('tipo_proceso');
            $table->string('resultado');
            $table->timestamp('fecha_proceso');
            $table->timestamp('nueva_fecha_caducidad')->nullable();
            $table->foreignId('user_fk')->constrained('users');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('componentes_procesados');
    }
};
