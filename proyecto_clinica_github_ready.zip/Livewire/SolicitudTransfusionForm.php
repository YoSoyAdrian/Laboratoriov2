<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\SolicitudTransfusion;
use App\Models\Paciente;
use Illuminate\Support\Str;

class SolicitudTransfusionForm extends Component
{
    public $paciente_fk;
    public $tipo_solicitud = 'rutina';
    public $numero_muestra;
    public $observaciones;

    public function mount()
    {
        $this->numero_muestra = strtoupper(Str::random(8));
    }

    public function save()
    {
        $this->validate([
            'paciente_fk' => 'required|exists:pacientes,id',
            'tipo_solicitud' => 'required|in:rutina,urgente,emergencia',
            'numero_muestra' => 'required|unique:solicitudes_transfusion,numero_muestra',
        ]);

        SolicitudTransfusion::create([
            'paciente_fk' => $this->paciente_fk,
            'tipo_solicitud' => $this->tipo_solicitud,
            'numero_muestra' => $this->numero_muestra,
            'fecha_solicitud' => now(),
            'estado' => 'pendiente',
            'user_solicita_fk' => auth()->id(),
            'observaciones' => $this->observaciones,
        ]);

        session()->flash('success', 'Solicitud registrada correctamente.');
        return redirect()->route('dashboard');
    }

    public function render()
    {
        return view('livewire.solicitud-transfusion-form', [
            'pacientes' => Paciente::all(),
        ]);
    }
}
