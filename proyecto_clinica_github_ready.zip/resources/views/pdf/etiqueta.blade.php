<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: DejaVu Sans; font-size: 12px; }
        .etiqueta {
            width: 5cm;
            height: 2cm;
            border: 1px solid #000;
            padding: 0.5cm;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="etiqueta">
        <strong>Paciente:</strong> {{ $solicitud->paciente->nombre }}<br>
        <strong>Muestra:</strong> {{ $solicitud->numero_muestra }}<br>
        <strong>Tipo:</strong> {{ ucfirst($solicitud->tipo_solicitud) }}
    </div>
</body>
</html>
