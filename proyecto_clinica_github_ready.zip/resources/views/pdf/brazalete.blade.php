<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 11px; }
        .brazalete {
            width: 7cm;
            height: 2.5cm;
            border: 2px dashed black;
            padding: 0.5cm;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="brazalete">
        <strong>Paciente:</strong> {{ $solicitud->paciente->nombre }}<br>
        <strong>Nº Muestra:</strong> {{ $solicitud->numero_muestra }}<br>
        <strong>Tipo:</strong> {{ ucfirst($solicitud->tipo_solicitud) }}
    </div>
</body>
</html>
