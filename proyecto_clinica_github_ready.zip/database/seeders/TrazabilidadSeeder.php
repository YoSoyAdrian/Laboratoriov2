<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Schema;

class TrazabilidadSeeder extends Seeder
{
    public function run(): void
    {
        // Ejecutar migraciones
        Artisan::call('migrate');

        // Copiar vistas PDF a resources/views/pdf si no existen
        if (!File::exists(resource_path('views/pdf/etiqueta.blade.php'))) {
            File::copy(database_path('../resources/views/pdf/etiqueta.blade.php'), resource_path('views/pdf/etiqueta.blade.php'));
        }

        if (!File::exists(resource_path('views/pdf/brazalete.blade.php'))) {
            File::copy(database_path('../resources/views/pdf/brazalete.blade.php'), resource_path('views/pdf/brazalete.blade.php'));
        }

        // Mostrar mensaje de instalación
        $this->command->info('Módulo de trazabilidad instalado correctamente.');
    }
}
